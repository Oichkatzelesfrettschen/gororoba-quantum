with builtins; with (import <nixpkgs> {}).lib;
{
  ## DO NOT CHANGE THIS
  format = "1.0.0";
  ## unless you made an automated or manual update
  ## to another supported format.

  ## The attribute to build, either from nixpkgs
  ## of from the overlays located in `.nix/coq-overlays`
  attribute = "mathcomp";

  ## If you want to select a different attribute
  ## to serve as a basis for nix-shell edit this
  shell-attribute = "mathcomp-single";

  ## Indicate the relative location of your _CoqProject
  ## If not specified, it defaults to "_CoqProject"
  coqproject = "_CoqProject";

  cachix.coq = {};
  cachix.coq-community = {};
  cachix.math-comp.authToken = "CACHIX_AUTH_TOKEN";

  ## select an entry to build in the following `bundles` set
  ## defaults to "default"
  default-bundle = "rocq-9.1";

  ## write one `bundles.name` attribute set per
  ## alternative configuration, the can be used to
  ## compute several ci jobs as well

  ## You can override Coq and other Coq coqPackages
  ## through the following attribute

  bundles = let
    master = [
      "coq-bits"
      "coqeal"
      "coquelicot"
      "ExtLib"
      "fcsl-pcm"
      "fourcolor"
      "gaia"
      "graph-theory"
      "interval"
      "mathcomp-abel"
      "mathcomp-algebra-tactics"
      "mathcomp-analysis"
      "mathcomp-apery"
      "mathcomp-bigenough"
      "mathcomp-classical"
      "mathcomp-finmap"
      "mathcomp-infotheo"
      "mathcomp-real-closed"
      "mathcomp-word"
      "mathcomp-zify"
      "multinomials"
      "odd-order"
      "QuickChick"
      "reglang"
      "simple-io"
      "mathcomp-tarjan"
      "deriving"
      "extructures"
    ];
    common-bundles = listToAttrs (forEach master (p:
      { name = p; value.override.version = "master"; }))
    // {
      mathcomp-boot.main-job = true;
      mathcomp-doc.job = true;
      mathcomp.job = false;
      stdlib.job = true;
      jasmin.override.version = "main";
      ssprove.override.version = "main";
      CertiRocq.job = false;
      ConCert.job = false;
      libvalidsdp.job = false;
      relation-algebra.job = false;
      validsdp.job = false;
      wasmcert.job = false;
      # To add an overlay applying to all bundles,
      # add below a line like
      #<package>.override.version = "<github_login>:<branch>";
      # where
      # * <package> will typically be one of the strings above (without the quotes)
      #   or look at https://github.com/NixOS/nixpkgs/tree/master/pkgs/development/coq-modules
      #   for a complete list of Coq packages available in Nix
      # * <github_login>:<branch> is such that this will use the branch <branch>
      #   from https://github.com/<github_login>/<repository>
    };
  in {
    "rocq-master".rocqPackages = common-bundles // {
      rocq-core.override.version = "master";
      coq.override.version = "master";
      rocq-elpi.override.version = "master";
      hierarchy-builder.override.version = "master";
      micromega-plugin.override.version = "master";
      stdlib.override.version = "master";
      bignums.override.version = "master";
      mathcomp.job = false;
      rocqnavi.override.version = "master";
      autosubst.job = false;
      interval.job = false;
      coquelicot.job = false;
      ssprove.job = false;
      mathcomp-infotheo.job = false;  # not compatible with master
      paco.override.version = "master";  # for jasmin
      paco.job = false;  # only for jasmin
      ITree.override.version = "master";  # for jasmin
      ITree.job = false;  # only for jasmin
    };
    "rocq-9.3".rocqPackages = common-bundles // {
      rocq-core.override.version = "9.3";
      coq.override.version = "9.3";
      coq-elpi.job = true;
      micromega-plugin.override.version = "master";
      micromega-plugin.job = false;
      hierarchy-builder.job = true;
      interval.job = false;
      jasmin.job = false;  # waiting for InteractionTrees
      ssprove.job = false;  # waiting for equations
      mathcomp-infotheo.job = false;  # not yet compatible with 9.3
      # check that we compile without warnings on last release of Coq
      mathcomp-warnings.job = true;
    };
    "rocq-9.2".rocqPackages = common-bundles // {
      rocq-core.override.version = "9.2";
      coq.override.version = "9.2";
      coq-elpi.job = true;
      micromega-plugin.override.version = "master";
      micromega-plugin.job = false;
      hierarchy-builder.job = true;
      interval.job = false;
      jasmin.job = false;  # waiting for InteractionTrees
      ssprove.job = false;  # waiting for equations
    };
    "rocq-9.1".rocqPackages = common-bundles // {
      rocq-core.override.version = "9.1";
      coq.override.version = "9.1";
      coq-elpi.job = true;
      micromega-plugin.override.version = "master";
      micromega-plugin.job = false;
      hierarchy-builder.job = true;
      ConCert.job = false;
      fcsl-pcm.job = false;  # fcsl-pcm dropped support for Rocq 9.1
    };
  };
}
