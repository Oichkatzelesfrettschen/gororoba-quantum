/*-----------------------------------------------------------------*/
/*! 
  \file scscpprocedureterminated.h
  \brief SCSCP message : procedure terminated.
   class SCSCP_procedureterminatedoptions, SCSCP_procedureterminated
  \author  M. Gastineau 
           Astronomie et Systemes Dynamiques, IMCCE, CNRS, Observatoire de Paris. 

   Copyright, 2008,  M. Gastineau, IMCCE-CNRS
   email of the author : gastineau@imcce.fr
*/
/*-----------------------------------------------------------------*/

/*-----------------------------------------------------------------*/
/* License  of this file :
 This file is "dual-licensed", you have to choose one  of the two licenses 
 below to apply on this file.
 
    CeCILL-C
    	The CeCILL-C license is close to the GNU LGPL.
    	( http://www.cecill.info/licences/Licence_CeCILL-C_V1-en.html )
 
 or CeCILL v2.0
      The CeCILL license is compatible with the GNU GPL.
      ( http://www.cecill.info/licences/Licence_CeCILL_V2-en.html )
 

This library is governed by the CeCILL-C or the CeCILL license under 
French law and abiding by the rules of distribution of free software.  
You can  use, modify and/ or redistribute the software under the terms 
of the CeCILL-C or CeCILL license as circulated by CEA, CNRS and INRIA  
at the following URL "http://www.cecill.info". 

As a counterpart to the access to the source code and  rights to copy,
modify and redistribute granted by the license, users are provided only
with a limited warranty  and the software's author,  the holder of the
economic rights,  and the successive licensors  have only  limited
liability. 

In this respect, the user's attention is drawn to the risks associated
with loading,  using,  modifying and/or developing or reproducing the
software by the user in light of its specific status of free software,
that may mean  that it is complicated to manipulate,  and  that  also
therefore means  that it is reserved for developers  and  experienced
professionals having in-depth computer knowledge. Users are therefore
encouraged to load and test the software's suitability as regards their
requirements in conditions enabling the security of their systems and/or 
data to be ensured and,  more generally, to use and operate it in the 
same conditions as regards security. 

The fact that you are presently reading this means that you have had
knowledge of the CeCILL-C or CeCILL license and that you accept its terms.
*/
/*-----------------------------------------------------------------*/


#ifndef __SCSCPPROCEDURETERMINATED_H__
#define __SCSCPPROCEDURETERMINATED_H__


#include "scscpoptions.h"

/*-----------------------------------------------------------------*/
/*! structure to manage the option of "Procedure terminated" */
/*-----------------------------------------------------------------*/
typedef  struct SCSCP_optionsprocedurereturn SCSCP_procedureterminatedoptions;

/*-----------------------------------------------------------------*/
/*! structure to manage the  Procedure termiated
*/
/*-----------------------------------------------------------------*/
typedef struct 
{
   /*-----------------------------------------------------------------*/
   /* attributes */
   /*-----------------------------------------------------------------*/
   SCSCP_procedureterminatedoptions*  m_ProcedureOptions; /*!< options of the procedure */
   SCSCP_string                     m_errormsg;   /*!< writeable error message */
   const_SCSCP_string               m_consterrormsg;   /*!< read-only error message */
   const_SCSCP_string               m_symbolname; /*!< symbol name */
   const_SCSCP_string               m_cdname;     /*!< cd name */
} SCSCP_procedureterminated;


/*-----------------------------------------------------------------*/
/*    functions */
/*-----------------------------------------------------------------*/
#if defined (__cplusplus)
extern "C" {
#endif

int SCSCP_procedureterminated_init(SCSCP_procedureterminated* procterm, 
                             SCSCP_procedureterminatedoptions* options,
                             const_SCSCP_string cdname,
                             const_SCSCP_string symbolname, 
                             SCSCP_string errormsg,
                             SCSCP_status *status);
int SCSCP_procedureterminated_init2(SCSCP_procedureterminated* procterm, 
                             SCSCP_procedureterminatedoptions* options,
                             const_SCSCP_string cdname,
                             const_SCSCP_string symbolname, 
                             const_SCSCP_string errormsg,
                             SCSCP_status *status);
int SCSCP_procedureterminated_clear(SCSCP_procedureterminated* procterm, SCSCP_status *status);
int SCSCP_procedureterminated_write(SCSCP_io *stream, const SCSCP_procedureterminated* procterm, SCSCP_status *status);
int SCSCP_procedureterminated_read(SCSCP_socketclient* client, SCSCP_xmlnodeptr* curnode, 
                                   SCSCP_procedureterminated* procterm, SCSCP_status *status);
const char* SCSCP_procedureterminated_getmessage(const SCSCP_procedureterminated* procterm);

#if defined (__cplusplus)
}
#endif

#endif /*__SCSCPPROCEDURETERMINATED_H__*/
