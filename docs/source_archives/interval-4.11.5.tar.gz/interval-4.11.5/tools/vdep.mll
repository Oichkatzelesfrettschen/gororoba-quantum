{

let backtrack lexbuf =
  let open Lexing in
  lexbuf.lex_curr_pos <- lexbuf.lex_start_pos;
  lexbuf.lex_curr_p <- lexbuf.lex_start_p

exception Syntax_error of int * int

let syntax_error lexbuf =
  raise (Syntax_error (Lexing.lexeme_start lexbuf, Lexing.lexeme_end lexbuf))

let rec normalize_path = function
  | ("" | ".") :: t -> normalize_path t
  | h :: t -> h :: normalize_path t
  | [] -> []

let rec concat_path = function
  | [] -> "."
  | [f] -> f
  | h::t -> h ^ "/" ^ concat_path t

let files = ref (Hashtbl.create 17)

let rec scan_files root path preflen logical =
  let d = Sys.readdir path in
  let scan f =
    let l = String.length f in
    let file = path ^ "/" ^ f in
    if Sys.is_directory file then
      scan_files root file preflen (f :: logical)
    else if l >= 3 && String.get f (l - 2) = '.' && String.get f (l - 1) = 'v' then
      let name = String.sub f 0 (l - 2) in
      let l =
        match Hashtbl.find_opt !files name with
        | Some l -> l
        | None -> [] in
      Hashtbl.replace !files name ((root, preflen, List.rev logical) :: l) in
  Array.iter scan d

let scan_files path logical =
  scan_files path (concat_path path) (List.length logical) (List.rev logical)

let rec drop n l =
  if n > 0 then drop (n - 1) (List.tl l) else l

let rec drop_last = function
  | [] -> assert false
  | [h] -> []
  | h::t -> h :: drop_last t

let rec is_prefix l1 l2 =
  match l1, l2 with
  | [], _ -> true
  | _, [] -> false
  | h1::t1, h2::t2 -> h1 = h2 && is_prefix t1 t2

let rec last = function
  | [] -> assert false
  | [x] -> x
  | h::t -> last t

let locate prefix suffix =
  let lp = List.length prefix in
  let ls = List.length suffix in
  let rec find = function
    | (root, _, logical) as h :: t ->
        let l = List.length logical in
        if lp + ls <= l + 1 && is_prefix prefix logical &&
             is_prefix (drop (l - ls + 1) logical) suffix then h
        else find t
    | [] -> raise Not_found in
  let f = last suffix in
  let rl = Hashtbl.find !files f in
  let (root, preflen, logical) = find rl in
  let p = List.flatten [root; drop preflen logical; [f ^ ".vo"]] in
  concat_path p

}

let space = [' ' '\t' '\n' '\r']+
let ident = ['A'-'Z' 'a'-'z'] ['A'-'Z' 'a'-'z' '0'-'9' '_']*
let qualid = ident ('.' ident)*

rule parse_vernac = parse
  | "(*"
    { skip_comment lexbuf;
      parse_vernac lexbuf }
  | "Require" space+
    { let r = do_require [] lexbuf in
      r :: parse_vernac lexbuf }
  | "From" space+ (qualid as q) space+ "Require" space+
    { let r = do_require (String.split_on_char '.' q) lexbuf in
      r :: parse_vernac lexbuf }
  | eof
    { [] }
  | _
    { skip_vernac lexbuf;
      parse_vernac lexbuf }

and do_require prefix = parse
  | "Import" space+
    { really_do_require prefix lexbuf }
  | "Export" space+
    { really_do_require prefix lexbuf }
  | _
    { backtrack lexbuf; really_do_require prefix lexbuf }

and really_do_require prefix = parse
  | (qualid as q) space*
    { match locate prefix (String.split_on_char '.' q) with
      | f -> f :: really_do_require prefix lexbuf
      | exception Not_found -> really_do_require prefix lexbuf }
  | '.' (space+ | eof)
    { [] }

and skip_vernac = parse
  | "(*"
    { skip_comment lexbuf; skip_vernac lexbuf }
  | '.' (space+ | eof)
    { () }
  | _
    { skip_vernac lexbuf }

and skip_comment = parse
  | "*)" space*
    { () }
  | "(*"
    { skip_comment lexbuf; skip_comment lexbuf }
  | eof
    { () }
  | _
    { skip_comment lexbuf }

{

let rec parse_args paths files = function
  | ("-R" | "-Q") :: p :: l :: args ->
      let p = normalize_path (String.split_on_char '/' p) in
      scan_files p (String.split_on_char '.' l);
      parse_args ((p, l) :: paths) files args
  | f :: args ->
      if String.length f < 3 || f.[0] = '-' then
        raise (Invalid_argument ("unrecognized command-line option " ^ f));
      let f = normalize_path (String.split_on_char '/' f) in
      parse_args paths (f :: files) args
  | [] -> (List.rev paths, List.rev files)

let handle_file paths f =
  let f = concat_path f in
  let ch = open_in f in
  let lexbuf = Lexing.from_channel ch in
  let r = parse_vernac lexbuf in
  close_in ch;
  print_string f;
  print_string "o:";
  List.iter (fun d -> print_char ' '; print_string d) (List.flatten r);
  print_newline ()

let () =
  let args = drop 1 (Array.to_list Sys.argv) in
  let (paths, files) = parse_args [] [] args in
  List.iter (fun f -> handle_file paths f) files

}
