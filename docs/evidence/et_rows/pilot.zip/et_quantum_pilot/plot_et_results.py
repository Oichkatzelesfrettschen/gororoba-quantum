#!/usr/bin/env python3
"""Render exact mathematical predictions; no hardware data are shown."""
import json
import io
import os
from pathlib import Path
import tempfile
os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "et-matplotlib-cache"))
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, BoundaryNorm
from PIL import Image
from et_reference import make_table, row_spectrum

root = Path(__file__).parent
fig = plt.figure(figsize=(13.3, 10.2), layout="constrained", facecolor="#f8f9fb")
gs = fig.add_gridspec(2, 2, height_ratios=[1.15, .95])
cmap = ListedColormap(["#2b73a8", "#eef0f3", "#e58634"])
norm = BoundaryNorm([-1.5,-.5,.5,1.5], cmap.N)
for i, s in enumerate((1,9)):
    ax = fig.add_subplot(gs[0,i])
    tab = make_table(32,s)
    vals = np.sign(np.array(tab["values"]))
    ax.imshow(vals, cmap=cmap, norm=norm, interpolation="nearest")
    labels = tab["labels"]
    ax.set_xticks(range(14), labels, fontsize=8)
    ax.set_yticks(range(14), labels, fontsize=8)
    ax.set_xlabel("Column low label (tone-row order)", fontsize=10)
    ax.set_ylabel("Row low label", fontsize=10)
    label = "Dense" if s == 1 else "Sand Mandala"
    ax.set_title(f"{label}: D = 32, S = {s}\n{tab['ordered_filled']} occupied ordered cells / 168 addressable", fontsize=13, loc="left", pad=12)
    ax.set_xticks(np.arange(-.5,14,1),minor=True)
    ax.set_yticks(np.arange(-.5,14,1),minor=True)
    ax.grid(which="minor",color="white",linewidth=.5)
    ax.tick_params(which="minor",bottom=False,left=False)
    for spine in ax.spines.values():spine.set_visible(False)
ax = fig.add_subplot(gs[1,0])
x=np.arange(3); width=.34
for offset,s,color,label in ((-.5,1,"#2b73a8","S=1, row 2: degree 12"),(.5,9,"#e58634","S=9, row 2: degree 4")):
    spectrum=row_spectrum(32,s,2)
    bars=ax.bar(x+offset*width,[spectrum[e] for e in (0,2,4)],width,color=color,label=label)
    ax.bar_label(bars,padding=3,fontsize=10)
ax.set_xticks(x,["0: annihilator","2","4"])
ax.set_ylim(0,29)
ax.set_ylabel("Exact eigenspace dimension")
ax.set_xlabel("Eigenvalue of encoded H = Lₐ† Lₐ")
ax.set_title("Row degree determines the Hamiltonian spectrum",fontsize=12,loc="left",pad=12)
ax.legend(frameon=False,fontsize=9,loc="upper left")
ax.spines[["top","right"]].set_visible(False)
ax = fig.add_subplot(gs[1,1])
report=json.loads((root/"circuits/coherence_verification.json").read_text())
case=next(c for c in report["cases"] if c["strut"]==9 and c["row"]==2)
probs=case["runs"][0]["low_column_x_probabilities"]
ax.bar(np.arange(16),probs,color="#2b73a8",width=.78,label="Coherent multiplication circuit")
ax.axhline(1/16,color="#d16b22",linestyle="--",linewidth=1.8,label="Fully column-dephased input")
ax.set_xticks(np.arange(16), labels=np.arange(16), fontsize=8)
ax.set_xlabel("Decoded column in Walsh (X) basis")
ax.set_ylabel("Ideal output probability")
ax.set_ylim(0,.45)
ax.set_title("A phase-sensitive control distinguishes lost coherence",fontsize=12,loc="left",pad=12)
ax.legend(frameon=False,fontsize=8,loc="upper left")
ax.text(.03,.64,"D=32, S=9, row 2\nTVD from dephased reference = 67/128",transform=ax.transAxes,fontsize=9)
ax.spines[["top","right"]].set_visible(False)
fig.suptitle("Emanation tables → a six-qubit multiplication experiment",fontsize=19,fontweight="bold")
fig.supxlabel("Exact computed references • blue ET cells: η = −1; orange: η = +1; pale: blank • no hardware measurements",fontsize=10)
buf = io.BytesIO()
fig.savefig(buf, format="png", dpi=150)
png_bytes = buf.getvalue()
with Image.open(io.BytesIO(png_bytes)) as check:
    check.load()
(root/"et_quantum_overview.png").write_bytes(png_bytes)
svg_buf = io.StringIO()
fig.savefig(svg_buf, format="svg")
(root/"et_quantum_overview.svg").write_text(svg_buf.getvalue())
print("PNG bytes:", len(png_bytes))
print(root/"et_quantum_overview.png")
