# Emanation-table quantum pilot

Verified offline on 2026-10-18. This package contains exact mathematics,
ideal quantum simulation, compilation screens, and a proposed first campaign.
No quantum hardware jobs were submitted. The repository QPU hold remains in
effect. The QASM/QPY files have not been admitted against a live provider Target.

## Main recommendation

Start with the six-qubit, column-resolved multiplication experiment for D=32 on
an accessible IBM Heron. Compare dense S=1,row=2, sparse S=9,row=2, and the
high-degree row S=9,row=8 inside the sparse table. Use two fixed dyad signs to
measure signed multiplication, plus decoded column-X readout and a phase-marker
control to test coherence. Use Tuna-17 for a shallower independent implementation
after its native circuit and connected healthy region are qualified. Keep Belenos
on its existing transformation-conformance work before admitting ET experiments.

The support oracle is a separate inexpensive check of an explicitly programmed
occupancy predicate. The fixed-sign multiplication experiment does not load the
ET occupancy or edge-sign table into preparation; it constructs the generic
signed left-multiplication operation and compares its output with the independent
ET reference.

## Files and reproduction

- `et_reference.py`: standard-library exact arithmetic, tables, row spectra,
  dyad products, output-column decoding and full finite census.
- `et_fixtures.json`: 116 signed tables at D=16,32,64,128, with source pins,
  label conventions, hashes, degrees and normalization fields.
- `qiskit_et_pilot.py`: generic SELECT, coherent full rows, support predicates,
  full-state references, exact matrix construction and compilation screening.
- `coherence_pilot.py`: physical output decoding, Walsh readout, dephased-column
  null reference, and marker-induced XOR shift.
- `build_first_campaign.py`: a concrete 12-circuit local proposal, including
  both fixed-sign arms. It cannot submit to a provider.
- `circuits/quantum_verification.json`: 60 ideal row circuits, five support
  oracles, five Hamiltonians and 41 screened compilation variants.
- `circuits/coherence_verification.json`: six additional coherence compilations,
  full joint and low-column marginal predictions.
- `circuits/first_campaign_plan.json`: twelve proposed signal cases, referring
  to existing artifacts and three additional fixed-minus compilations.
- `circuits/*.qpy`: the 50 distinct authoritative compiled circuit artifacts.
- `circuits/*.qasm`: human-readable physical-wire gate streams. Import with
  `qasm2.LEGACY_CUSTOM_INSTRUCTIONS`; phase and layout are external metadata.
- `audit/`: independent integer audits, signed embedding checks, balloon data,
  and affine-preparation candidates.
- `et_quantum_overview.png` and `.svg`: exact mathematical predictions.
- `sources.json`: pinned source and primary documentation links.
- `manifest.json`: file hashes and verification summary.

Run in a fresh virtual environment with Python 3.12:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-pilot.txt
.venv/bin/python et_reference.py
.venv/bin/python qiskit_et_pilot.py
.venv/bin/python coherence_pilot.py
.venv/bin/python build_first_campaign.py
```

The mathematical reference needs no installed dependencies. Plot generation is
optional and additionally needs Matplotlib and Pillow. Every released verifier
refuses `python -O/-OO`, which would otherwise disable its assertions. Exact
integer predicates are distinct from floating-point operator comparisons.

Qiskit screening uses version 2.6.0, optimization level 3, seed 230, and the basis
`rz,sx,x,cz`. All-to-all and selected line-connectivity screens are abstract
architectures, not actual IBM or Tuna ISA circuits. They contain unitary programs;
the eventual backend wrapper must add the specified measurements and preserve the
physical-to-logical mapping. Never send these files directly under an old approval.

## Source pins and required integration fixes

- open_gororoba: `84cefcaf64755f004da4d485f1ef1fe16f4eb0c7`.
- gororoba-quantum: `832c9b671abf2f4a47683558f33b8d2cc83e47c4`.
- Its separate CI algebra dependency pin:
  `7d95d228db6be8a5b2f613430f04f2385d6ae48a`.

Keep these identities separate. Importing the current algebra snapshot does not
silently update the quantum repository's dependency contract.

The requested K-by-K assessor table is implemented by
`crates/algebra_experimental/src/emanation/strutted_et.rs::create_strutted_et`.
`table_builder.rs::emanation_table` constructs a different (D-1)-by-(D-1)
basis-index diagnostic. Its stale comments cannot define the quantum object.

`carry_bit_overflow_cells` compares parent and child cross-assessors using
different high-index ranges. This is a reclassification, not a demonstration
that an inherited zero product becomes nonzero. The standard embedding of the
old algebra preserves its multiplication. In particular,
`(e2+e11)(e4-e13)=0` at D16, D32 and D64.

`theorem11.rs` checks shifted occupancy but does not check every shifted signed
entry. The independent finite audit adds those checks, passing every valid
strut through D128. The theorem's source is de Marrais's 2007 Part III,
arXiv:0704.0112v3, not the 2004 title in the source comment.

`skybox.rs` creates same-level padding with zero border DMZs. Theorem 11 converts
label lines into actual cells in the next dimension. For S15, the embedded D32
box in D64 has 72 interior occupied cells plus 56 occupied border cells, totaling
128. These require separate child-level fixtures. A correct principal-block
embedding does not imply that full graph time evolution remains in that block:
new off-block edges can couple it to the rest of the child table.

## Exact ET convention

Let D=2^N, G=D/2, X=G XOR S, K=G-2. Low labels are 1 through G-1 excluding S.
Label l denotes assessor (l,l XOR X). Its strut opposite is l XOR S. Addressable
cells omit the self and strut-opposite columns, giving K(K-2) ordered cells.

Write e_p e_q = s(p,q)e_(p XOR q), with the convention
`(a,b)(c,d)=(ac-conj(d)b, da+b conj(c))`. For row l and column c, put h=l XOR X,
k=c XOR X, eta1=s(h,c)s(l,k), eta2=s(h,k)s(l,c). An admissible cell is occupied
exactly when eta1=eta2. Its numerical entry is eta*(l XOR c).

The numerical sign eta has a precise operational meaning:
`(e_l+sigma e_h)(e_c+tau e_k)=0` iff `sigma*tau=-eta` on occupied cells.
Do not substitute the paper's named positive/negative edge convention for this
numerical sign. Store occupancy, sign, emanation index and validity separately.

Counts below are ordered cells. The number of undirected edges is half as large.

| D | S | Filled per table | Degree multiplicities |
|---:|---|---:|---|
|32|1-8|168|12:14|
|32|9-15|72|4:12, 12:2|
|64|1-8,16|840|28:30|
|64|9-15|456|12:24, 28:6|
|64|17-24|168|4:28, 28:2|
|64|25-31|552|4:4, 20:24, 28:2|
|128|1-8,16,32|3720|60:62|
|128|9-15|2184|28:48, 60:14|
|128|17-24|1032|12:56, 60:6|
|128|25-31|2568|12:8, 44:48, 60:6|
|128|33-40,48|360|4:60, 60:2|
|128|41-47|1896|4:12, 36:48, 60:2|
|128|49-56|3048|4:4, 52:56, 60:2|
|128|57-63|1512|4:4, 20:48, 52:8, 60:2|

For D32, S=8+r, r in 1..7, hubs are r and 8. Every other valid row l has exactly
four neighbors: r,8,l XOR r,l XOR 8. The hubs each have degree12. This supplies
an exact bitwise predicate for the first synthesis search.

## Row degree equals annihilator dimension

For a=e_l+e_h, define H=L_a^dagger L_a. Pair the data basis as (c,c XOR X),
c=0..G-1. The exact H block is

```text
[[2, eta1(c)+eta2(c)],
 [eta1(c)+eta2(c), 2]]
```

An occupied block has eigenvalues 0 and 4, with null vector
`(|c>-eta|c XOR X>)/sqrt(2)`. All other blocks, including the four excluded low
labels {0,S,l,l XOR S}, are 2I. Thus if row degree is d, the exact spectrum has
0 repeated d times, 2 repeated D-2d times, and 4 repeated d times. The kernel of
L_a has dimension d, and summing these dimensions over rows gives the ET's filled
ordered-cell count. This applies to the stated two-basis assessors, not arbitrary
multi-term Cayley-Dickson elements.

The trace is always 2D. An incoherent uniform basis average gives selector0
probability1/2 for both dense and sparse tables. There is no native-QPU energy or
new physical field inferred from this constructed dimensionless Hamiltonian.

## Actual coherent multiplication experiment

Prepare all G low labels uniformly, including explicit padding/control labels:

`|Psi_tau> = sum_c (|c>+tau|c XOR X>)/sqrt(2G)`.

This takes N data qubits: N-1 low-label Hadamards, one high-bit Hadamard, optional
Z for tau=-1, and controlled XOR of S from the high bit into the low bits. Add
one selector qubit, H-SELECT-H, with

`SELECT|a,z> = s(m_a,z)|a,z XOR m_a>`, m0=l, m1=h.

The selector0 block is L_a/2. Measure every data bit and the selector. Decode
the source column by `c=l XOR z` for z<G and `c=l XOR (z XOR X)` otherwise.
This can be done classically for computational-basis measurement. Different
columns occupy disjoint output pairs; no separate address register is needed.

For each c, `p_tau(0|c)=1/2+tau*(eta1+eta2)/4`. The two fixed-sign arms predict
(1,0), (0,1), or(1/2,1/2), distinguishing both occupied signs from blanks.

For D32,S9,row2, occupied columns1,3 have eta=-1; columns8,10 have eta=+1.
Every other padded column predicts1/2 in both arms. The unconditional selector
average is1/2 in both arms; preserve the complete joint law.

The algorithmic widths are 6, 7, 8 qubits at D32,64,128. The generic signed SELECT
operator is checked over all 2D basis states. Complete preparation states are
also checked by an independent signed path sum, including inter-column phases.

## A coherence control beyond computational-basis probabilities

Before measurement, physically decode the output pair: controlled XOR S from
the high data bit, then XOR l on the low bits. Apply H to every low bit and
measure. The resulting low register is in the Walsh (X) basis.

A fully column-dephased state gives a uniform low-X distribution under trusted
Walsh readout, regardless of its classical column probabilities. For D32,S9,row2,
the coherent fixed-plus prediction is

`[1,9,11,3,1,25,11,3,1,1,3,3,1,1,51,3]/128`.

Its low-column TV distance from uniform is 67/128. The full joint distribution
has TV distance 71/128 from the specified component-mixture null. These are
different statistics. A Z phase on input column bit 0 shifts the coherent Walsh
labels by XOR 1 but has no effect after complete column dephasing. Include that
marker control and appropriate readout calibration on hardware.

## Matched and affine preparation as separate optimized controls

On occupied cells set tau(c)=-eta(c) for dark, +eta(c) for bright. With the
padded G-column preparation, p_dark=(G-d)/(2G), p_bright=(G+d)/(2G); contrast=d/G.
D32 degree 4 gives 3/8 and 5/8; degree 12 gives 1/8 and 7/8. Averaging rows yields
contrast F/(KG); recover conditional table fill by multiplying by G/(K-2).

Blank-column phase can be chosen freely for these selector/column statistics.
An affine completion tau(c)=(-1)^(b XOR parity(mask AND c)) uses only an optional
high-bit Z and a few CZ gates. The code searches and exactly checks each such
completion. Every D32 S8-S15 row admits one in the independent census. This does
not establish the same property for arbitrary higher-dimensional ETs.

Affine preparation is not identical to the reference matched preparation on
blank columns. It has its own complete-state contract. It reduces preparation
cost without changing the generic SELECT operation. The independent fixed-sign
arms remain the primary multiplication benchmark.

## Concrete compilation results

These are logical CZ-basis screens, without a calibrated device or duration.

| D,S,row | Preparation | Sign synthesis | Connectivity | CZ count |
|---|---|---|---|---:|
|32,9,2|fixed-plus|diagonal|all-to-all|57|
|32,9,2|fixed-plus|direct ANF|all-to-all|201|
|32,9,2|matched-dark|diagonal|all-to-all|69|
|32,9,2|affine-dark|diagonal|all-to-all|58|
|32,9,2|fixed-plus|diagonal|line|144|
|32,9,2|affine-dark|diagonal|line|145|
|64,9,2|fixed-plus|diagonal|all-to-all|105|
|128,9,2|fixed-plus|diagonal|all-to-all|197|

The compiled D32 fixed-row support oracles use 7 CZ for the dense control and
13 for the sparse nonhub control. Their reversible predicates differ from the
actual multiplication experiment. Factored affine-parity predicates and shared
MAJ/phase/uncompute are useful next optimization candidates; a high Boolean
degree or short expression alone does not predict native cost.

Qiskit `qubits_initially_zero=True` permits promised-zero-state optimization.
In this environment a direct ANF row had full-unitary discrepancy 0.1768 under
that promise while its intended zero-input state was correct to numerical
precision. Setting `qubits_initially_zero=False` restores the reusable arbitrary
input contract. This is a contract distinction, not an established Qiskit bug.
Future clean-ancilla optimizations may use a separate verified isometry contract.

QPY is authoritative because OpenQASM2 does not preserve the global phase and
layout by itself. Each text stream is verified after restoring its recorded
global phase; each QPY is loaded and checked against the original logical unitary.
Avoid dense full-unitary expansion after a real Target creates 156 physical wires;
verify the compact logical operator, then validate the routed ISA and layout on
the relevant reduced representation.

## Backend allocation

IBM: compile against captured Targets for ibm_kingston, ibm_fez, ibm_marrakesh;
the audited account exposes 156-qubit Heron r2 devices. Choose by routed duration,
readout and predicted column/phase contrast. Keep conventional CZ and fractional
variants separate; current API supports fractional and dynamic gates together,
but fractional twirling/PEC/PEA-ZNE restrictions and runtime-specific DD/twirling
rules remain. Read actual Target gate errors, not generic documentation claims.

Tuna: the retained exclusions leave an11-qubit connected usable component, not
17 freely available wires. Use exact supported angles/Clifford+T, CZ routing,
and matched neighbor/readout conditions. Official timings are 20 ns single-qubit,
60 ns CZ, 800 ns measurement; rotations round to pi/36. Mid-circuit measurement
does not provide general binary-controlled gates. The existing specialized
sedenion SELECT must not be reused as if it handled arbitrary D32 rows.

QX: the account snapshot has 10 qubits. Use static, reset-free conformance. The
retained hosted reset experiment damages a neighbor's phase on the tested input;
do not adopt reset-bearing hosted QX as the reference for dynamic cleanup.

Belenos:24 modes, not a universal12-qubit gate register. A one-photon14-mode
ET row state or unitary graph walk can fit; a generic14-by-14 nonunitary Halmos
dilation needs 28 modes and does not. Small2,4,8-dimensional blocks fit 4-, 8-, 16-mode
dilations. A full32-dimensional CD data state with an LCU flag would need 64 modes
in this single-photon encoding. Existing mesh29dc6ef8 single-job results implement
the wrong target-block transformation; preserve complete mode histograms and
qualify the exact job form before a new ET campaign.

CPU first: six-to-eight-qubit statevectors occupy 1–4 KiB, and their density matrices
64 KiB–1 MiB before software overhead. GPU/JAX/TPU are useful for large repeated
noise/parameter ensembles after structured export and reuse, not for a single
tiny reference. Device execution must be proven by retained telemetry.

## Twelve-case first campaign proposal

For each of the three D32 rows, retain fixed-plus and fixed-minus Z-joint cases,
then fixed-plus column-X with marker0 and marker1. This is 12 signal circuits.
The plan proposes 8192 shots each, 98,304 signal shots plus separately budgeted
controls. For the Z-joint arms, the ideal expected number of samples per padded
column is 512. At conditional p=1/2, the binomial standard error is approximately
0.022 before systematic error, multiplicity or between-batch drift. The column-X
arms use their separately retained nonuniform multinomial predictions. These
numbers are a reviewable design proposal, not an authorization, duration
quotation or hardware acquisition.

Use repeated blocks and retain randomized order, execution timestamps and exact
calibration identities. Do not assume shot-array neighbors are temporal neighbors
on IBM. Estimate signed per-column contrasts with intervals; applying abs() or
squaring noisy contrasts to estimate occupancy creates bias near zero. Evaluate
the known signed law, phase-shift control and readout controls jointly.

## Doubling and later research

For fixed9<=S<=15, F_N=(5/8)G^2-6G+8. Counts at D32,64,128,256,512 are
72,456,2184,9480,39432; fill tends to 5/8 and count growth tends to 4. A moving
strut S=G/2+1 instead has F=6(G-4), growth tending to 2 and fill tending to 0.
Keep fixed-strut and moving-strut sequences distinct.

Use the exact classical census and signed embedding certificates first. Then
transfer the same row contracts across D32->64->128, adding one address/data
qubit per doubling. Do not spend quantum shots re-estimating a known closed form
without a circuit-fidelity or scaling question.

Whole-table operators require a separate choice: Boolean adjacency, signed
adjacency, and the literal integer-valued ET are different operators. Specify
padding, norm bound, block-encoding normalization and acceptance cost. Signed
basis gauges must transform preparation and readout too. An ET entry's XOR index
is a label, not an automatically justified physical coupling magnitude.

DQI follows as a separate seven-qubit coherent-cleanup benchmark. The chemistry
and spectrum-amplification connection becomes useful for more complex operators,
such as tested sums involving different struts or three-term perturbations.
The present row H has a known three-valued spectrum, so VQE/QPE adds little.
Cultivation and large reversible decoders remain separate later simulation
families; their hardware requirements and conditional acceptance cannot be
inferred from this ET pilot.

The mathematical object is an encoded linear operator derived from a
nonassociative algebra. The quantum gates and Hilbert-space operators obey ordinary
associative quantum mechanics. No physical nonassociativity, unique kickback
mechanism, new field, quantum advantage, or fault-tolerant code is established.
