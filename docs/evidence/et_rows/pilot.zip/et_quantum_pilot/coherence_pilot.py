#!/usr/bin/env python3
"""ET inter-column coherence controls, with an explicit dephased null model."""
from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np
from qiskit.quantum_info import Statevector

from et_reference import basis_sign, decode_output_column, parameters
from qiskit_et_pilot import (
    compile_and_verify, direct_state_reference, phase_for_mode, row_circuit,
)

if not __debug__:
    raise RuntimeError("This verifier requires assertions; run without python -O/-OO")


def column_components(dim, strut, row, mode):
    """Unnormalized pure components, one per classical mixture label.

    Their coherent sum is the original state; sum of their outer products is
    complete dephasing of the input column register, before the multiplication.
    """
    _, g, x = parameters(dim, strut)
    out = np.zeros((g, 2 * dim), complex)
    for c in range(g):
        tau = phase_for_mode(dim, strut, row, c, mode)
        for high in (0, 1):
            source = c ^ (x if high else 0)
            for branch in (0, 1):
                left = row ^ (x if branch else 0)
                amp = (tau if high else 1) * basis_sign(dim, left, source) / (2 * math.sqrt(dim))
                for selector in (0, 1):
                    out[c, selector * dim + (source ^ left)] += amp * (-1) ** (selector * branch)
    return out


def column_x_transform(state, dim, strut, row):
    """Independent basis relabeling and normalized Walsh transform."""
    _, g, _ = parameters(dim, strut)
    decoded = np.zeros(2 * dim, complex)
    for z, amp in enumerate(state):
        selector, data = divmod(z, dim)
        high = int(data >= g)
        col = decode_output_column(dim, strut, row, data)
        decoded[selector * dim + high * g + col] = amp
    output = np.zeros_like(decoded)
    for fixed in range(4):
        for k in range(g):
            output[fixed * g + k] = sum(decoded[fixed * g + c] * (-1) ** ((k & c).bit_count() & 1)
                                              for c in range(g)) / math.sqrt(g)
    return output


def add_coherence_readout(qc, dim, strut, row):
    n, _, _ = parameters(dim, strut)
    qc = qc.copy()
    qc.name += "_column_X"
    qc.barrier()
    for bit in range(n - 1):
        if strut & (1 << bit):
            qc.cx(n - 1, bit)
        if row & (1 << bit):
            qc.x(bit)
    qc.h(range(n - 1))
    return qc


def run():
    output = Path(__file__).with_name("circuits")
    output.mkdir(exist_ok=True)
    report = {"hardware_submissions": 0, "basis": "Walsh X on decoded low-column bits; Z on dyad-high and selector", "cases": []}
    for dim, strut, row in ((32, 1, 2), (32, 9, 2), (32, 9, 8)):
        _, g, _ = parameters(dim, strut)
        mode = "fixed_plus"
        components = column_components(dim, strut, row, mode)
        assert np.max(abs(components.sum(axis=0) - direct_state_reference(dim, strut, row, mode))) < 1e-14
        mixed_p = sum((abs(column_x_transform(v, dim, strut, row)) ** 2 for v in components))
        runs = []
        for marker in (0, 1):
            qc = add_coherence_readout(row_circuit(dim, strut, row, mode, column_marker=marker), dim, strut, row)
            expected = column_x_transform(direct_state_reference(dim, strut, row, mode, column_marker=marker), dim, strut, row)
            state = Statevector.from_instruction(qc).data
            error = float(np.max(abs(state - expected)))
            assert error < 2e-12
            probs = abs(state) ** 2
            tvd = float(.5 * np.sum(abs(probs - mixed_p)))
            low_p = probs.reshape(4, g).sum(axis=0)
            low_mixed_p = mixed_p.reshape(4, g).sum(axis=0)
            assert np.max(abs(low_mixed_p - 1/g)) < 2e-12
            low_tvd = float(.5 * np.sum(abs(low_p - low_mixed_p)))
            assert tvd > .05
            runs.append({"column_marker": marker, "full_statevector_error": error,
                         "coherent_vs_column_dephased_tvd": tvd,
                         "low_column_x_probabilities": low_p.tolist(),
                         "low_column_x_tvd_from_uniform": low_tvd,
                         "coherent_probabilities": probs.tolist(),
                         "dephased_probabilities": mixed_p.tolist(),
                         "compilation": compile_and_verify(qc, output)})
        p0, p1 = [np.array(x["coherent_probabilities"]).reshape(4, g) for x in runs]
        shifted = p0[:, np.arange(g) ^ 1]
        shift_err = float(np.max(abs(p1 - shifted)))
        assert shift_err < 2e-12
        report["cases"].append({"dimension": dim, "strut": strut, "row": row,
                                "marker_walsh_shift_error": shift_err, "runs": runs})
    target = output / "coherence_verification.json"
    target.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"output": str(target), "cases": [
        {"strut": x["strut"], "row": x["row"], "coherent_vs_dephased_tvd": x["runs"][0]["coherent_vs_column_dephased_tvd"]}
        for x in report["cases"]]}, indent=2))


if __name__ == "__main__":
    run()
