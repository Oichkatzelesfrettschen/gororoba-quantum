#!/usr/bin/env python3
"""Independent exact CD ET analysis; no external dependencies or hardware calls."""

if not __debug__:
    raise RuntimeError("Verification requires assertions; do not run with python -O/-OO.")
from functools import lru_cache
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path

@lru_cache(None)
def sign(d,p,q):
    if d == 1: return 1
    h=d//2
    if p<h and q<h: return sign(h,p,q)
    if p<h: return sign(h,q-h,p)
    if q<h: return sign(h,p-h,q)*(1 if q==0 else -1)
    return -1 if q==h else sign(h,q-h,p-h)

def cdp_sign(l,r):
    signs=((1,1,1,1),(1,-1,1,-1),(1,-1,-1,1),(1,1,-1,-1))
    s=1
    while True:
        if not l or not r: return s
        if l==r: return -s
        lb,rb=l.bit_length(),r.bit_length()
        if lb<3 and rb<3: return s*signs[l][r]
        if lb==rb:
            g=1<<(lb-1)
            if l==g: return s
            if r==g: return -s
            if l^r==g: return -s if r>l else s
            s=-s;l-=g;r-=g
        elif lb<rb:
            g=1<<(rb-1)
            if r==g:return s
            if l^r==g:return -s
            s=-s;r-=g
        else:
            g=1<<(lb-1)
            if l^r==g:return s
            s=-s
            if l==g:return s
            l-=g

def cell(n,s,l,c):
    d=1<<n;g=d//2;x=g^s
    if not 0<l<g or not 0<c<g or l==s or c==s or l==c or l^c==s:
        return 0
    hl,hc=l^x,c^x
    a=sign(d,hl,c)*sign(d,l,hc)
    b=sign(d,hl,hc)*sign(d,l,c)
    return a*(l^c) if a==b else 0

def table(n,s):
    labels=[l for l in range(1,1<<(n-1)) if l!=s]
    a={l:{c:cell(n,s,l,c) for c in labels} for l in labels}
    degrees={l:sum(v!=0 for v in row.values()) for l,row in a.items()}
    return a,{
        'dimension':1<<n,'n':n,'strut':s,'k':len(labels),
        'addressable':len(labels)*(len(labels)-2),'filled':sum(degrees.values()),
        'degree_histogram':dict(sorted(Counter(degrees.values()).items())),
        'negative_entries':sum(v<0 for row in a.values() for v in row.values()),
        'positive_entries':sum(v>0 for row in a.values() for v in row.values()),
        'degrees_by_label':degrees,
    }

def diagonal_product(n,s,l,c,sigma,tau):
    d=1<<n;x=d//2^s;out=Counter()
    for p,pv in ((l,1),(l^x,sigma)):
        for q,qv in ((c,1),(c^x,tau)):
            out[p^q]+=pv*qv*sign(d,p,q)
    return {k:v for k,v in out.items() if v}

def audit():
    mismatches=[]
    for d in (4,8,16,32,64,128):
        for l in range(d):
            for c in range(d):
                if sign(d,l,c)!=cdp_sign(l,c):mismatches.append([d,l,c])
    assert not mismatches
    census=[]
    diagonal_tests=0
    for n in (4,5,6,7):
        for s in range(1,1<<(n-1)):
            a,summary=table(n,s);census.append(summary)
            for l,row in a.items():
                for c,v in row.items():
                    assert v==a[c][l]
                    if l==c or l^c==s:continue
                    products={(sigma,tau):diagonal_product(n,s,l,c,sigma,tau) for sigma in (-1,1) for tau in (-1,1)}
                    assert bool(v)==any(not p for p in products.values())
                    if v:
                        edge=1 if v>0 else -1
                        assert all(bool(prod)==(sigma*tau!=-edge) for (sigma,tau),prod in products.items())
                    diagonal_tests+=1
    transitions=[]
    for n in (4,5,6):
        for s in range(1,1<<(n-1)):
            a,_=table(n,s);g=1<<(n-1)
            primary=[];shifted=[];shifted_values=[]
            for l,row in a.items():
                for c,v in row.items():
                    v0=cell(n+1,s,l,c);v1=cell(n+1,s,l+g,c+g)
                    if v!=v0:primary.append([l,c,v,v0])
                    if bool(v)!=bool(v1):shifted.append([l,c,v,v1])
                    if v!=v1:shifted_values.append([l,c,v,v1])
            transitions.append({'n':n,'s':s,'primary_value_mismatches':len(primary),'shifted_occupancy_mismatches':len(shifted),'shifted_value_mismatches':len(shifted_values),'shifted_first':shifted_values[:2]})
    balloons=[]
    for s in (1,8,9,15,17,24,25,31,33,63):
        ride=[]
        for n in range(max(4,s.bit_length()+1),10):
            _,a=table(n,s)
            a['fill_fraction']=str(Fraction(a['filled'],a['addressable']))
            if ride:a['growth_fraction']=str(Fraction(a['filled'],ride[-1]['filled']))
            ride.append(a)
        balloons.append({'strut':s,'ride':ride,'monotone':all(Fraction(a['filled'],a['addressable'])<=Fraction(b['filled'],b['addressable']) for a,b in zip(ride,ride[1:]))})
    bridge_blocks=0
    for n in (4,5,6,7):
        d=1<<n;g=d//2
        for s in range(1,g):
            x=g^s
            for l in range(1,g):
                if l==s:continue
                h=l^x;degree=0;spectrum=Counter()
                for c in range(g):
                    hc=c^x
                    eta1=sign(d,h,c)*sign(d,l,hc)
                    eta2=sign(d,h,hc)*sign(d,l,c)
                    v=cell(n,s,l,c)
                    if v:
                        degree+=1
                        assert eta1+eta2==2*(1 if v>0 else -1)
                    else:
                        assert eta1+eta2==0
                    spectrum[2+eta1+eta2]+=1
                    spectrum[2-eta1-eta2]+=1
                    bridge_blocks+=1
                assert spectrum[0]==degree and spectrum[4]==degree
                assert spectrum[2]==d-2*degree
    return {'source_commit':'84cefcaf64755f004da4d485f1ef1fe16f4eb0c7','basis_sign_mismatches':mismatches,'diagonal_tests':diagonal_tests,'hamiltonian_bridge_blocks':bridge_blocks,'census':census,'transitions':transitions,'balloons':balloons}

if __name__=='__main__':
    result=audit()
    out=Path(__file__).with_name('et_integer_audit_results.json')
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'output':str(out),'basis_sign_mismatches':result['basis_sign_mismatches'],'diagonal_tests':result['diagonal_tests'],'census_groups':{n:dict(Counter(str((a['filled'],a['degree_histogram'])) for a in result['census'] if a['n']==n)) for n in (4,5,6,7)},'transition_failure_counts':{field:sum(t[field]>0 for t in result['transitions']) for field in ('primary_value_mismatches','shifted_occupancy_mismatches','shifted_value_mismatches')},'first_shifted_mismatches':[t for t in result['transitions'] if t['shifted_value_mismatches']][:2],'balloons':[{ 'strut':b['strut'],'monotone':b['monotone'],'counts':[(a['dimension'],a['filled'],a['fill_fraction'],a.get('growth_fraction')) for a in b['ride']]} for b in result['balloons']]},indent=2))
