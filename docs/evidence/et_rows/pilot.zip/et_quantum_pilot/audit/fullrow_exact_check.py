#!/usr/bin/env python3
"""Independent exact check of coherent ET rows, with no circuit-library dependency."""

if not __debug__:
    raise RuntimeError("Verification requires assertions; do not run with python -O/-OO.")
from collections import Counter
from fractions import Fraction
import json
from pathlib import Path
from et_integer_audit import sign,cell

def verify():
    cases=0
    for n in (4,5,6,7):
        d=1<<n;g=d//2
        for s in range(1,g):
            x=g^s
            for l in range(1,g):
                if l==s:continue
                h=l^x;degree=sum(bool(cell(n,s,l,c)) for c in range(g))
                for bright in (False,True):
                    psi=[0]*d
                    for c in range(g):
                        v=cell(n,s,l,c)
                        eta=(1 if v>0 else -1) if v else 0
                        tau=eta if bright and v else (-eta if v else 1)
                        psi[c]=1;psi[c^x]=tau
                    p0=[0]*d;p1=[0]*d
                    for k,p in enumerate(psi):
                        p0[l^k]+=p*sign(d,l,k);p0[h^k]+=p*sign(d,h,k)
                        p1[l^k]+=p*sign(d,l,k);p1[h^k]-=p*sign(d,h,k)
                    probability=Fraction(sum(a*a for a in p0),4*d)
                    expected=Fraction(1,2)+(1 if bright else -1)*Fraction(degree,2*g)
                    assert probability==expected
                    joint=Counter()
                    for selector,vec in enumerate((p0,p1)):
                        for z,amp in enumerate(vec):
                            c=l^(z^x if z>=g else z)
                            joint[c,selector]+=amp*amp
                    for c in range(g):
                        assert joint[c,0]+joint[c,1]==8
                        occupied=bool(cell(n,s,l,c))
                        target=8 if bright and occupied else 0 if occupied else 4
                        assert joint[c,0]==target
                    cases+=1
    return {'cases':cases,'dimensions':[16,32,64,128],'all_valid_struts':True,'all_valid_rows':True,'both_arms':True,'all_low_column_labels_including_excluded':True,'exact_integer_amplitudes':True,'rational_normalization':True,'joint_distribution_and_decoding_verified':True,'hardware_runs':0}

if __name__=='__main__':
    result=verify()
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result))
