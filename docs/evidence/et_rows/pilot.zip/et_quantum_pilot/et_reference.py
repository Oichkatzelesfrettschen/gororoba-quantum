#!/usr/bin/env python3
"""Exact emanation-table and left-multiplication references. Standard library only.

Convention: (a,b)(c,d)=(ac-conj(d)b, da+b conj(c)); e_p e_q=s(p,q)e_(p xor q).
ET signs are the numerical signs in strutted_et.rs, not de Marrais's named
positive/negative edge convention. An occupied cell of numerical sign eta
annihilates right-dyad sign tau=-eta when the left-dyad sign is +1.

This file has no account, network, or quantum hardware interface.
"""
from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
from functools import lru_cache
import hashlib
import json
from pathlib import Path

if not __debug__:
    raise RuntimeError("This verifier requires assertions; run without python -O/-OO")

SOURCE_PINS = {
    "open_gororoba": "84cefcaf64755f004da4d485f1ef1fe16f4eb0c7",
    "gororoba_quantum": "832c9b671abf2f4a47683558f33b8d2cc83e47c4",
    "quantum_ci_algebra_pin": "7d95d228db6be8a5b2f613430f04f2385d6ae48a",
}


def parameters(dim: int, strut: int) -> tuple[int, int, int]:
    if type(dim) is not int or dim < 16 or dim & (dim - 1):
        raise ValueError("dim must be a power of two, at least 16")
    if type(strut) is not int or not 1 <= strut < dim // 2:
        raise ValueError("strut must be an integer in [1, dim/2)")
    return dim.bit_length() - 1, dim // 2, (dim // 2) ^ strut


@lru_cache(maxsize=None)
def _sign(dim: int, p: int, q: int) -> int:
    if dim == 1:
        return 1
    h = dim // 2
    if p < h and q < h:
        return _sign(h, p, q)
    if p < h:
        return _sign(h, q - h, p)
    if q < h:
        return _sign(h, p - h, q) * (1 if q == 0 else -1)
    return -1 if q == h else _sign(h, q - h, p - h)


def basis_sign(dim: int, p: int, q: int) -> int:
    if type(dim) is not int or dim < 1 or dim & (dim - 1):
        raise ValueError("dim must be a positive power of two")
    if any(type(i) is not int or not 0 <= i < dim for i in (p, q)):
        raise ValueError("basis indices must lie in [0, dim)")
    return _sign(dim, p, q)


def tone_row(dim: int, strut: int) -> list[int]:
    _, g, _ = parameters(dim, strut)
    front = [i for i in range(1, g) if i != strut and i < (i ^ strut)]
    return front + [i ^ strut for i in reversed(front)]


def block_signs(dim: int, strut: int, row: int, col: int) -> tuple[int, int]:
    _, g, x = parameters(dim, strut)
    if type(row) is not int or not 0 < row < g or row == strut:
        raise ValueError("row must be a valid low assessor label")
    if type(col) is not int or not 0 <= col < g:
        raise ValueError("col must lie in the padded low-label register")
    h, k = row ^ x, col ^ x
    eta1 = _sign(dim, h, col) * _sign(dim, row, k)
    eta2 = _sign(dim, h, k) * _sign(dim, row, col)
    return eta1, eta2


def cell(dim: int, strut: int, row: int, col: int) -> dict:
    _, g, x = parameters(dim, strut)
    if any(type(v) is not int or not 0 <= v < g for v in (row, col)):
        raise ValueError("row and col must lie in [0, dim/2)")
    admissible = row not in (0, strut) and col not in (0, strut, row, row ^ strut)
    eta1, eta2 = block_signs(dim, strut, row, col) if row not in (0, strut) else (1, -1)
    occupied = admissible and eta1 == eta2
    eta = eta1 if occupied else 0
    return {
        "row": row, "row_high": row ^ x, "col": col, "col_high": col ^ x,
        "admissible": admissible, "occupied": occupied,
        "eta": eta, "emanation_index": (row ^ col) if occupied else 0,
        "emanation_value": eta * (row ^ col),
    }


def row_degree(dim: int, strut: int, row: int) -> int:
    _, g, _ = parameters(dim, strut)
    block_signs(dim, strut, row, 0)
    return sum(cell(dim, strut, row, c)["occupied"] for c in range(g))


def row_spectrum(dim: int, strut: int, row: int) -> dict[int, int]:
    d = row_degree(dim, strut, row)
    return {0: d, 2: dim - 2 * d, 4: d}


def dyad_product(dim: int, strut: int, row: int, col: int, tau: int) -> dict[int, int]:
    if tau not in (-1, 1):
        raise ValueError("tau must be +1 or -1")
    _, _, x = parameters(dim, strut)
    block_signs(dim, strut, row, col)
    out = Counter()
    for p, a in ((row, 1), (row ^ x, 1)):
        for q, b in ((col, 1), (col ^ x, tau)):
            out[p ^ q] += a * b * _sign(dim, p, q)
    return {k: v for k, v in out.items() if v}


def dyad_p0(dim: int, strut: int, row: int, col: int, tau: int) -> Fraction:
    # Right state is divided by sqrt(2); LCU block by 2: total norm factor 1/8.
    prod = dyad_product(dim, strut, row, col, tau)
    return Fraction(sum(v * v for v in prod.values()), 8)


def row_tau(dim: int, strut: int, row: int, col: int, bright: bool) -> int:
    item = cell(dim, strut, row, col)
    if not item["occupied"]:
        return 1
    return item["eta"] if bright else -item["eta"]


def decode_output_column(dim: int, strut: int, row: int, data_index: int) -> int:
    _, g, x = parameters(dim, strut)
    if not 0 <= data_index < dim:
        raise ValueError("data index outside register")
    low_output = data_index ^ x if data_index >= g else data_index
    return row ^ low_output


def row_p0(dim: int, strut: int, row: int, bright: bool) -> Fraction:
    _, g, _ = parameters(dim, strut)
    d = row_degree(dim, strut, row)
    return Fraction(g + (d if bright else -d), 2 * g)


def make_table(dim: int, strut: int) -> dict:
    n, g, x = parameters(dim, strut)
    labels = tone_row(dim, strut)
    values = [[cell(dim, strut, r, c)["emanation_value"] for c in labels] for r in labels]
    degrees = [sum(v != 0 for v in row) for row in values]
    f = sum(degrees)
    k = len(labels)
    body = {
        "dimension": dim, "n": n, "generator": g, "strut": strut, "xor_pair_mask": x,
        "labels": labels, "high_labels": [i ^ x for i in labels], "values": values,
        "ordered_addressable": k * (k - 2), "ordered_filled": f,
        "undirected_edges": f // 2, "degrees": degrees,
        "degree_histogram": dict(sorted(Counter(degrees).items())),
        "conditional_fill_fraction": str(Fraction(f, k * (k - 2))),
        "padded_cell_flag_probability": str(Fraction(f, g * g)),
        "sign_semantics": "zero product iff sigma*tau=-eta on occupied cells",
    }
    raw = json.dumps(body, sort_keys=True, separators=(",", ":")).encode()
    body["sha256"] = hashlib.sha256(raw).hexdigest()
    return body


def verify(dimensions=(16, 32, 64, 128)) -> dict:
    blocks = cells = 0
    tables = []
    for dim in dimensions:
        _, g, _ = parameters(dim, 1)
        for s in range(1, g):
            tab = make_table(dim, s)
            labels, values = tab["labels"], tab["values"]
            assert sum(tab["degrees"]) == tab["ordered_filled"]
            assert all(values[i][j] == values[j][i] for i in range(len(labels)) for j in range(len(labels)))
            for l in labels:
                zero_blocks = 0
                for c in range(g):
                    eta1, eta2 = block_signs(dim, s, l, c)
                    b = eta1 + eta2
                    item = cell(dim, s, l, c)
                    assert (b != 0) == item["occupied"]
                    assert b == 2 * item["eta"]
                    zero_blocks += abs(b) == 2
                    for tau in (-1, 1):
                        assert dyad_p0(dim, s, l, c, tau) == Fraction(2 + tau * b, 4)
                    if item["occupied"]:
                        assert not dyad_product(dim, s, l, c, -item["eta"])
                    for z in (l ^ c, (l ^ c) ^ (g ^ s)):
                        assert decode_output_column(dim, s, l, z) == c
                    blocks += 1
                    cells += item["admissible"]
                assert zero_blocks == row_degree(dim, s, l)
                spec = row_spectrum(dim, s, l)
                assert sum(spec.values()) == dim
                assert sum(e * count for e, count in spec.items()) == 2 * dim
                for bright in (False, True):
                    exact_mean = sum((dyad_p0(dim, s, l, c, row_tau(dim, s, l, c, bright)) for c in range(g)), Fraction()) / g
                    assert exact_mean == row_p0(dim, s, l, bright)
            tables.append(tab)
    return {
        "source_pins": SOURCE_PINS, "convention": __doc__,
        "verification": {"exact_paired_blocks": blocks, "ordered_admissible_cells": cells,
                         "matrix_reference": "direct integer dyad multiplication",
                         "hardware_submissions": 0},
        "tables": tables,
    }


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", type=Path, default=Path(__file__).with_name("et_fixtures.json"))
    args = ap.parse_args()
    result = verify()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps({"file": str(args.output), **result["verification"], "tables": len(result["tables"])}, indent=2))


if __name__ == "__main__":
    main()
