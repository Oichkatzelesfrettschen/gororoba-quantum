#!/usr/bin/env python3
"""Compile and verify static ET row circuits locally; never submit a quantum job.

Requires qiskit==2.6.0 and numpy. The emitted CZ-basis circuits are architecture
screening artifacts, not backend-admitted ISA circuits or hardware results.
Actual provider Targets, calibration, routing and submission remain separate.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import math
from functools import lru_cache
from pathlib import Path

import numpy as np
import qiskit
from qiskit import QuantumCircuit, qasm2, qpy, transpile
from qiskit.circuit.library import DiagonalGate, XGate, ZGate
from qiskit.quantum_info import Operator, Statevector
from qiskit.transpiler import CouplingMap

if not __debug__:
    raise RuntimeError("This verifier requires assertions; run without python -O/-OO")

from et_reference import (
    SOURCE_PINS, basis_sign, block_signs, cell, decode_output_column,
    parameters, row_degree, row_p0, row_tau,
)


def anf_masks(truth: list[int]) -> list[int]:
    if not truth or len(truth) & (len(truth) - 1) or any(v not in (0, 1) for v in truth):
        raise ValueError("truth table must have power-of-two length with Boolean entries")
    work = truth.copy()
    for bit in range(len(work).bit_length() - 1):
        for mask in range(len(work)):
            if mask & (1 << bit):
                work[mask] ^= work[mask ^ (1 << bit)]
    return [mask for mask, value in enumerate(work) if value]


def append_phase(qc: QuantumCircuit, signs: list[int], qubits: list[int], strategy: str) -> None:
    if len(signs) != 1 << len(qubits) or any(s not in (-1, 1) for s in signs):
        raise ValueError("phase diagonal must have the full signed basis domain")
    if strategy == "diagonal":
        qc.append(DiagonalGate(signs), qubits)
    elif strategy == "anf":
        for mask in anf_masks([int(s < 0) for s in signs]):
            qs = [qubits[b] for b in range(len(qubits)) if mask & (1 << b)]
            if not qs:
                qc.global_phase += math.pi
            elif len(qs) == 1:
                qc.z(qs[0])
            else:
                qc.append(ZGate().control(len(qs) - 1, annotated=False), qs)
    else:
        raise ValueError("strategy must be diagonal or anf")


def selected_multiplication(dim: int, strut: int, row: int, strategy: str) -> QuantumCircuit:
    n, _, x = parameters(dim, strut)
    block_signs(dim, strut, row, 0)
    h = row ^ x
    qc = QuantumCircuit(n + 1, name=f"SELECT_D{dim}_S{strut}_L{row}")
    signs = [basis_sign(dim, h if z >= dim else row, z % dim) for z in range(2 * dim)]
    append_phase(qc, signs, list(range(n + 1)), strategy)
    for bit in range(n):
        if row & (1 << bit):
            qc.x(bit)
        if x & (1 << bit):
            qc.cx(n, bit)
    return qc


@lru_cache(maxsize=None)
def affine_completion(dim: int, strut: int, row: int) -> tuple[int, int] | None:
    """Find a smallest affine extension of the specified dark phases.

    Blank phases may vary in this separate preparation contract. The complete
    resulting state, not only its selector marginal, is checked below.
    """
    _, g, _ = parameters(dim, strut)
    candidates = []
    for mask in range(g):
        for offset in (0, 1):
            if all(not cell(dim, strut, row, c)["occupied"] or
                   (-1) ** (offset ^ ((mask & c).bit_count() & 1)) == -cell(dim, strut, row, c)["eta"]
                   for c in range(g)):
                candidates.append((mask.bit_count() + offset, mask.bit_count(), mask, offset))
    if not candidates:
        return None
    _, _, mask, offset = min(candidates)
    return mask, offset


def phase_for_mode(dim: int, strut: int, row: int, col: int, mode: str) -> int:
    if mode == "fixed_plus":
        return 1
    if mode == "fixed_minus":
        return -1
    if mode in ("matched_dark", "matched_bright"):
        return row_tau(dim, strut, row, col, mode == "matched_bright")
    if mode in ("affine_dark", "affine_bright"):
        completion = affine_completion(dim, strut, row)
        if completion is None:
            raise ValueError("row has no affine dark-phase completion")
        mask, offset = completion
        return (-1) ** (offset ^ ((mask & col).bit_count() & 1) ^ (mode == "affine_bright"))
    raise ValueError("unknown row mode")


def row_circuit(dim: int, strut: int, row: int, mode: str, strategy="diagonal", column_marker=0) -> QuantumCircuit:
    """Coherent full row with N data qubits and selector N.

    fixed_plus/fixed_minus do not load any ET signs in state preparation:
    they implement the independent multiplication experiment. matched_dark /
    matched_bright prepare classically predicted dyad phases and aggregate
    row degree into the selector contrast. All G column labels, including
    four explicit blank/excluded cases, remain in the joint measurement law.
    """
    n, g, _ = parameters(dim, strut)
    if type(column_marker) is not int or not 0 <= column_marker < g:
        raise ValueError("column_marker must fit the low-label register")
    block_signs(dim, strut, row, 0)
    if mode not in ("fixed_plus", "fixed_minus", "matched_dark", "matched_bright", "affine_dark", "affine_bright"):
        raise ValueError("unknown row mode")
    qc = QuantumCircuit(n + 1, name=f"row_D{dim}_S{strut}_L{row}_{mode}_{strategy}")
    if column_marker:
        qc.name += f"_marker{column_marker}"
    qc.h(range(n))
    for bit in range(n - 1):
        if column_marker & (1 << bit):
            qc.z(bit)
    high = n - 1
    if mode == "fixed_minus":
        qc.z(high)
    elif mode.startswith("matched_"):
        signs = [1] * g + [row_tau(dim, strut, row, c, mode == "matched_bright") for c in range(g)]
        append_phase(qc, signs, list(range(n)), strategy)
    elif mode.startswith("affine_"):
        completion = affine_completion(dim, strut, row)
        if completion is None:
            raise ValueError("row has no affine dark-phase completion")
        mask, offset = completion
        if offset ^ (mode == "affine_bright"):
            qc.z(high)
        for bit in range(n - 1):
            if mask & (1 << bit):
                qc.cz(high, bit)
    for bit in range(n - 1):
        if strut & (1 << bit):
            qc.cx(high, bit)
    # A barrier marks the state-preparation / generic multiplication contract.
    qc.barrier()
    qc.h(n)
    qc.compose(selected_multiplication(dim, strut, row, strategy), inplace=True)
    qc.h(n)
    return qc


def support_oracle(dim: int, strut: int, row: int) -> QuantumCircuit:
    """Full reversible |c,z> -> |c,z xor occupied(row,c)>; one output flag."""
    n, g, _ = parameters(dim, strut)
    truth = [int(cell(dim, strut, row, c)["occupied"]) for c in range(g)]
    qc = QuantumCircuit(n, name=f"support_D{dim}_S{strut}_L{row}")
    flag = n - 1
    for mask in anf_masks(truth):
        qs = [b for b in range(n - 1) if mask & (1 << b)]
        if not qs:
            qc.x(flag)
        else:
            qc.append(XGate().control(len(qs), annotated=False), qs + [flag])
    return qc


def direct_joint_reference(dim: int, strut: int, row: int, mode: str) -> np.ndarray:
    _, g, _ = parameters(dim, strut)
    result = np.zeros((g, 2), dtype=float)
    for c in range(g):
        tau = phase_for_mode(dim, strut, row, c, mode)
        a, b = block_signs(dim, strut, row, c)
        p0 = .5 + tau * (a + b) / 4
        result[c] = (p0 / g, (1 - p0) / g)
    return result


def direct_state_reference(dim: int, strut: int, row: int, mode: str, column_marker=0) -> np.ndarray:
    """Independent signed path sum, including inter-column relative phases."""
    _, g, x = parameters(dim, strut)
    out = np.zeros(2 * dim, dtype=complex)
    for c in range(g):
        tau = phase_for_mode(dim, strut, row, c, mode)
        for high in (0, 1):
            input_label = c ^ (x if high else 0)
            for branch in (0, 1):
                left_label = row ^ (x if branch else 0)
                amp = ((tau if high else 1) * basis_sign(dim, left_label, input_label) *
                       (-1) ** ((c & column_marker).bit_count() & 1) / (2 * math.sqrt(dim)))
                for selector in (0, 1):
                    output_label = input_label ^ left_label
                    out[selector * dim + output_label] += amp * (-1) ** (selector * branch)
    return out


def measured_joint(qc: QuantumCircuit, dim: int, strut: int, row: int) -> np.ndarray:
    _, g, _ = parameters(dim, strut)
    out = np.zeros((g, 2))
    for z, p in enumerate(Statevector.from_instruction(qc).probabilities()):
        c = decode_output_column(dim, strut, row, z % dim)
        out[c, int(z >= dim)] += float(p)
    return out


def verify_select(qc: QuantumCircuit, dim: int, strut: int, row: int) -> float:
    _, _, x = parameters(dim, strut)
    expected = np.zeros((2 * dim, 2 * dim), dtype=complex)
    for z in range(2 * dim):
        s, c = divmod(z, dim)
        left = row ^ x if s else row
        expected[s * dim + (left ^ c), z] = basis_sign(dim, left, c)
    return float(np.max(np.abs(Operator(qc).data - expected)))


def verify_hamiltonian(dim: int, strut: int, row: int) -> dict:
    _, g, x = parameters(dim, strut)
    left = np.zeros((dim, dim), dtype=np.int64)
    for c in range(dim):
        for p in (row, row ^ x):
            left[p ^ c, c] += basis_sign(dim, p, c)
    h = left.T @ left
    predicted = np.zeros_like(h)
    for c in range(g):
        z = c ^ x
        a, b = block_signs(dim, strut, row, c)
        predicted[c, c] = predicted[z, z] = 2
        predicted[c, z] = predicted[z, c] = a + b
    assert np.array_equal(h, predicted)
    eig = np.linalg.eigvalsh(h)
    d = row_degree(dim, strut, row)
    exact_eig = np.array([0] * d + [2] * (dim - 2 * d) + [4] * d)
    error = float(np.max(np.abs(eig - exact_eig)))
    assert error < 1e-11
    return {"dimension": dim, "strut": strut, "row": row, "degree": d,
            "nullity": d, "spectrum_multiplicities": {"0": d, "2": dim-2*d, "4": d},
            "matrix_identity_exact": True, "floating_spectrum_error": error}


def compile_and_verify(qc: QuantumCircuit, output: Path, topology="all_to_all", seed=230) -> dict:
    coupling = None
    if topology == "line":
        coupling = CouplingMap.from_line(qc.num_qubits, bidirectional=True)
    compiled = transpile(qc, basis_gates=["rz", "sx", "x", "cz"], coupling_map=coupling,
                         optimization_level=3, seed_transpiler=seed, qubits_initially_zero=False)
    # from_circuit applies the tracked initial/final layouts before comparison.
    error = float(np.max(np.abs(Operator.from_circuit(compiled).data - Operator(qc).data)))
    assert error < 2e-10, (qc.name, topology, error)
    fname = f"{qc.name}_{topology}.qasm"
    qasm = qasm2.dumps(compiled)
    (output / fname).write_text(qasm + "\n")
    # QPY is the authoritative reusable artifact: QASM 2 cannot carry global
    # phase or Qiskit's virtual-to-physical layout metadata.
    qpy_name = fname.replace(".qasm", ".qpy")
    stream = io.BytesIO()
    qpy.dump(compiled, stream)
    payload = stream.getvalue()
    (output / qpy_name).write_bytes(payload)
    restored = qpy.load(io.BytesIO(payload))[0]
    qpy_error = float(np.max(np.abs(Operator.from_circuit(restored).data - Operator(qc).data)))
    assert qpy_error < 2e-10
    # Verify the text gate stream in physical wire order with its phase restored.
    text_restored = qasm2.loads(qasm, custom_instructions=qasm2.LEGACY_CUSTOM_INSTRUCTIONS)
    text_restored.global_phase = compiled.global_phase
    qasm_error = float(np.max(np.abs(Operator(text_restored).data - Operator(compiled).data)))
    assert qasm_error < 2e-10
    counts = dict(compiled.count_ops())
    return {"file": fname, "authoritative_qpy": qpy_name, "source_name": qc.name, "topology": topology,
            "qubits": compiled.num_qubits, "gate_counts": counts,
            "depth": compiled.depth(), "cz_depth": compiled.depth(lambda item: item.operation.name == "cz"),
            "full_unitary_max_error": error, "qpy_roundtrip_error": qpy_error, "qasm_phase_restored_error": qasm_error,
            "global_phase_rad": float(compiled.global_phase),
            "initial_index_layout": compiled.layout.initial_index_layout() if compiled.layout else list(range(qc.num_qubits)),
            "final_index_layout": compiled.layout.final_index_layout() if compiled.layout else list(range(qc.num_qubits)),
            "qubits_initially_zero": False,
            "qasm2_import": "qasm2.loads(text, custom_instructions=qasm2.LEGACY_CUSTOM_INSTRUCTIONS)",
            "qasm_sha256": hashlib.sha256((qasm+"\n").encode()).hexdigest(),
            "qpy_sha256": hashlib.sha256(payload).hexdigest(),
            "resource_scope": "CZ basis, no calibrated backend, no duration/noise estimate"}


def run(output: Path) -> dict:
    output.mkdir(parents=True, exist_ok=True)
    report = {"source_pins": SOURCE_PINS, "qiskit_version": qiskit.__version__,
              "numpy_version": np.__version__, "seed_transpiler": 230,
              "hardware_submissions": 0, "hamiltonians": [], "rows": [], "compilations": [], "oracles": []}
    # Same S9 nonhub row follows the fixed-S balloon; S1 is a dense control.
    cases = [(32, 1, 2), (32, 9, 2), (32, 9, 8), (64, 9, 2), (128, 9, 2)]
    for dim, s, row in cases:
        report["hamiltonians"].append(verify_hamiltonian(dim, s, row))
        for strategy in ("diagonal", "anf"):
            sel_error = verify_select(selected_multiplication(dim, s, row, strategy), dim, s, row)
            assert sel_error < 2e-12
            modes = ["fixed_plus", "fixed_minus", "matched_dark", "matched_bright"]
            if affine_completion(dim, s, row) is not None:
                modes += ["affine_dark", "affine_bright"]
            for mode in modes:
                qc = row_circuit(dim, s, row, mode, strategy)
                joint = measured_joint(qc, dim, s, row)
                expected = direct_joint_reference(dim, s, row, mode)
                state_err = float(np.max(np.abs(Statevector.from_instruction(qc).data - direct_state_reference(dim, s, row, mode))))
                assert state_err < 2e-12
                err = float(np.max(np.abs(joint - expected)))
                assert err < 2e-12
                rec = {"dimension": dim, "strut": s, "row": row, "mode": mode,
                       "sign_strategy": strategy, "degree": row_degree(dim, s, row),
                       "algorithmic_qubits": qc.num_qubits, "p_selector_zero": float(joint[:,0].sum()),
                       "joint_max_error": err, "full_statevector_error": state_err, "select_full_signed_operator_error": sel_error,
                       "joint_by_low_column": joint.tolist()}
                if mode.startswith(("matched_", "affine_")):
                    rec["analytic_p0"] = str(row_p0(dim, s, row, mode.endswith("bright")))
                if mode.startswith("affine_"):
                    rec["dark_affine_mask_offset"] = list(affine_completion(dim, s, row))
                report["rows"].append(rec)
                # Screen two preparations per case; conjugate sign arms checked above.
                if mode in ("fixed_plus", "matched_dark", "affine_dark"):
                    report["compilations"].append(compile_and_verify(qc, output))
                    if dim == 32 and s == 9 and row == 2:
                        report["compilations"].append(compile_and_verify(qc, output, "line"))
        oracle = support_oracle(dim, s, row)
        n, g, _ = parameters(dim, s)
        expected = np.zeros((2*g, 2*g), complex)
        for z in range(2*g):
            col = z % g
            expected[z ^ (g if cell(dim, s, row, col)["occupied"] else 0), z] = 1
        oerr = float(np.max(np.abs(Operator(oracle).data - expected)))
        assert oerr < 2e-12
        witness = QuantumCircuit(n, name=oracle.name + "_uniform")
        witness.h(range(n-1))
        witness.compose(oracle, inplace=True)
        probability = float(sum(Statevector.from_instruction(witness).probabilities()[g:]))
        assert abs(probability - row_degree(dim, s, row)/g) < 2e-12
        report["oracles"].append({"dimension": dim, "strut": s, "row": row,
                                  "full_permutation_max_error": oerr, "p_flag_one": probability})
        report["compilations"].append(compile_and_verify(witness, output))
    (output / "quantum_verification.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--output", type=Path, default=Path(__file__).with_name("circuits"))
    args = ap.parse_args()
    report = run(args.output)
    print(json.dumps({"output": str(args.output), "row_circuits_verified": len(report["rows"]),
                      "support_oracles_verified": len(report["oracles"]),
                      "compiled_circuits": len(report["compilations"]),
                      "hardware_submissions": 0,
                      "compilation_summary": [{"name": x["source_name"], "topology": x["topology"],
                                               "cz": x["gate_counts"].get("cz", 0), "depth": x["depth"]}
                                              for x in report["compilations"]]}, indent=2))
