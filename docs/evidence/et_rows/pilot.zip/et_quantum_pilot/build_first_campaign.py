#!/usr/bin/env python3
"""Assemble a reviewable local 12-circuit candidate set; no provider calls."""
import json
from pathlib import Path
from qiskit_et_pilot import compile_and_verify, row_circuit

if not __debug__:
    raise RuntimeError("This verifier requires assertions; run without python -O/-OO")


def run():
    out = Path(__file__).with_name("circuits")
    screening = json.loads((out / "quantum_verification.json").read_text())
    coherence = json.loads((out / "coherence_verification.json").read_text())
    cases = []
    for dim, s, row in ((32, 1, 2), (32, 9, 2), (32, 9, 8)):
        for mode in ("fixed_plus", "fixed_minus"):
            qc = row_circuit(dim, s, row, mode)
            existing = next((c for c in screening["compilations"]
                             if c["source_name"] == qc.name and c["topology"] == "all_to_all"), None)
            artifact = existing or compile_and_verify(qc, out)
            cases.append({"dimension": dim, "strut": s, "row": row, "arm": mode,
                          "measurement": "Z on every logical data bit and the selector; decode column classically",
                          "suggested_shots": 8192, "artifact": artifact})
        cc = next(c for c in coherence["cases"] if c["strut"] == s and c["row"] == row)
        for case in cc["runs"]:
            cases.append({"dimension": dim, "strut": s, "row": row,
                          "arm": "column_X_marker_" + str(case["column_marker"]),
                          "measurement": "Z on all bits after embedded decode + Walsh column readout",
                          "suggested_shots": 8192, "artifact": case["compilation"]})
    plan = {
        "status": "offline_candidate_only",
        "hardware_authorization": False,
        "backend_admission_complete": False,
        "primary_backend_family": "accessible IBM Heron; choose after actual Target compilation",
        "suggested_signal_circuits": len(cases),
        "suggested_signal_shots": sum(c["suggested_shots"] for c in cases),
        "excluded_from_shot_sum": "fresh readout, phase-reference, and stationarity controls; must be budgeted separately",
        "budget_status": "no provider duration or credit quotation has been acquired",
        "hardware_next_steps": [
            "Compile source circuits against the exact chosen backend Target, preserving the approved contract.",
            "Validate routed layout, all measured logical bits, duration, calibration identity and expected joint laws.",
            "Plan bracketing readout and stationarity controls, and randomize arm order with a retained seed.",
            "Bind final artifacts and total resource quotation through the repository native preflight and QPU guard.",
        ],
        "cases": cases,
    }
    target = out / "first_campaign_plan.json"
    target.write_text(json.dumps(plan, indent=2) + "\n")
    print(json.dumps({"output": str(target), "cases": len(cases),
                      "signal_shots_if_admitted": plan["suggested_signal_shots"],
                      "hardware_submissions": 0}, indent=2))


if __name__ == "__main__":
    run()
