#!/bin/sh
set -eu
cd "$HOME/work"
./cg-run.sh w8_d3 78G 86400 "$HOME/tools/sage_wheels/bin/Singular" -q --no-rc --cpus=1 input.sing || true
date -u +%FT%TZ > all.done
