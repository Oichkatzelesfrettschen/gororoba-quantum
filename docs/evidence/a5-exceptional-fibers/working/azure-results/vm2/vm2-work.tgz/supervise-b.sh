#!/bin/sh
# Method B special fibers, one job at a time: E8-bar->N+, then W8->N-. Writes b.done when both have ended.
set -eu
cd "$HOME/work"
B=$HOME/tools/sage_wheels/bin/Singular
./cg-run.sh e8_b 78G 36000 "$B" -q --no-rc --cpus=1 input.sing || true
./cg-run.sh w8_b 78G 36000 "$B" -q --no-rc --cpus=1 input.sing || true
date -u +%FT%TZ > b.done
