#!/bin/sh
set -eu
cd "$HOME/work"
./cg-run.sh e8nm_d3 78G 129600 "$HOME/tools/sage_wheels/lib/python3.12/site-packages/sage_wheels/bin/Singular" -q --no-rc --cpus=1 input.sing || true
date -u +%FT%TZ > all.done
