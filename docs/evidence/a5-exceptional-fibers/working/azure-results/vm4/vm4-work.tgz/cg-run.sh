#!/bin/sh
# Run one job in a transient cgroup scope (MemoryMax, no swap) with a 30 s RSS trace; writes NAME.exit when done.
# Usage: cg-run.sh NAME MEMMAX TIMEOUT_S COMMAND [ARGS...]
set -eu
name=$1; mem=$2; to=$3; shift 3
cd "$HOME/work/$name"
date -u +%s > started
sudo -n systemd-run --scope -q --uid="$(id -u)" --gid="$(id -g)" -p MemoryMax="$mem" -p MemorySwapMax=0 \
  env MALLOC_ARENA_MAX=2 timeout -k 30 "$to" "$@" > out.log 2>&1 < /dev/null & pid=$!
(
  printf 'elapsed_s\trss_kib\tmem_available_kib\n'
  start=$(cat started)
  while kill -0 "$pid" 2>/dev/null; do
    rss=$(ps -C Singular -o rss= | awk '{s+=$1} END {print s+0}')
    avail=$(awk '/^MemAvailable:/ {print $2}' /proc/meminfo)
    printf '%s\t%s\t%s\n' $(( $(date -u +%s) - start )) "$rss" "$avail"
    sleep 30
  done
) > samples.tsv &
status=0; wait "$pid" || status=$?
echo "$status" > exit
